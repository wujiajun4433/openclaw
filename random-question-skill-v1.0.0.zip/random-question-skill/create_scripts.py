#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 install.sh 和 uninstall.sh 脚本
"""

import os
from pathlib import Path

# install.sh 内容
install_sh_content = '''#!/bin/bash
# Random Question Skill 安装脚本
# 版本: 1.0.0

set -e

echo "🔧 开始安装 Random Question Skill v1.0.0"
echo "========================================"

# 检查 OpenClaw 安装
if ! command -v openclaw &> /dev/null; then
    echo "❌ 错误: OpenClaw 未安装或不在 PATH 中"
    exit 1
fi

echo "✅ 检测到 OpenClaw"

# 获取安装目录
OPENCLAW_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
WORKSPACE_DIR="$OPENCLAW_HOME/workspace"
SKILLS_DIR="$WORKSPACE_DIR/skills"
RANDOM_QUESTION_DIR="$SKILLS_DIR/random-question"

echo "📁 安装目录: $OPENCLAW_HOME"
echo ""
echo "📦 正在安装技能文件..."

# 创建目录结构
mkdir -p "$RANDOM_QUESTION_DIR"
mkdir -p "$RANDOM_QUESTION_DIR/scripts"
mkdir -p "$RANDOM_QUESTION_DIR/config"
mkdir -p "$RANDOM_QUESTION_DIR/logs"
mkdir -p "$RANDOM_QUESTION_DIR/docs"

# 复制文件
echo "📄 复制文件..."
cp -r . "$RANDOM_QUESTION_DIR/" 2>/dev/null || true

# 设置执行权限
chmod +x "$RANDOM_QUESTION_DIR/scripts/random_selector.py"
chmod +x "$RANDOM_QUESTION_DIR/scripts/question_stats.py"

echo ""
echo "✅ 安装完成！"
echo ""
echo "📋 后续步骤："
echo "1. 查看技能详情: openclaw skill info random-question"
echo "2. 测试技能: openclaw run '随机问我一个问题'"
echo "3. 配置 Heartbeat: 编辑 $WORKSPACE_DIR/HEARTBEAT.md"
echo ""
echo "🚀 开始使用吧！"
'''

# uninstall.sh 内容
uninstall_sh_content = '''#!/bin/bash
# Random Question Skill 卸载脚本
# 版本: 1.0.0

set -e

echo "🗑️  开始卸载 Random Question Skill"
echo "=================================="

# 获取安装目录
OPENCLAW_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
WORKSPACE_DIR="$OPENCLAW_HOME/workspace"
SKILLS_DIR="$WORKSPACE_DIR/skills"
RANDOM_QUESTION_DIR="$SKILLS_DIR/random-question"

echo "📁 安装目录: $OPENCLAW_HOME"

# 确认卸载
read -p "确定要卸载 Random Question Skill 吗？(y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ 卸载已取消"
    exit 0
fi

# 备份配置文件
echo "💾 备份配置文件..."
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/tmp/openclaw-backup-$TIMESTAMP"
mkdir -p "$BACKUP_DIR"

if [ -d "$RANDOM_QUESTION_DIR/config" ]; then
    cp -r "$RANDOM_QUESTION_DIR/config" "$BACKUP_DIR/"
    echo "✅ 备份配置文件"
fi

if [ -d "$RANDOM_QUESTION_DIR/logs" ]; then
    cp -r "$RANDOM_QUESTION_DIR/logs" "$BACKUP_DIR/"
    echo "✅ 备份日志文件"
fi

# 删除技能目录
echo "🗑️  删除技能文件..."
if [ -d "$RANDOM_QUESTION_DIR" ]; then
    rm -rf "$RANDOM_QUESTION_DIR"
    echo "✅ 删除技能目录"
fi

echo ""
echo "✅ 卸载完成！"
echo "📁 备份文件保存在: $BACKUP_DIR"
echo ""
echo "👋 感谢使用 Random Question Skill！"
'''

# 创建脚本
def create_scripts():
    base_dir = Path("C:/Users/17985/Desktop/新建文件夹")
    
    # 创建 install.sh
    install_path = base_dir / "install.sh"
    with open(install_path, 'w', encoding='utf-8') as f:
        f.write(install_sh_content)
    os.chmod(install_path, 0o755)
    print(f"✅ 创建 install.sh: {install_path}")
    
    # 创建 uninstall.sh
    uninstall_path = base_dir / "uninstall.sh"
    with open(uninstall_path, 'w', encoding='utf-8') as f:
        f.write(uninstall_sh_content)
    os.chmod(uninstall_path, 0o755)
    print(f"✅ 创建 uninstall.sh: {uninstall_path}")

if __name__ == "__main__":
    create_scripts()
    print("\n✅ 所有脚本已创建！")
