#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
问题统计脚本
版本: 1.0.0
作者: 咕咕嘎嘎
功能: 分析随机提问技能的使用情况
"""

import json
import os
from datetime import datetime
from pathlib import Path
from collections import Counter

class QuestionAnalyzer:
    """问题分析器"""
    
    def __init__(self, data_dir=None):
        if data_dir is None:
            data_dir = Path.home() / ".openclaw" / "workspace" / "skills" / "random-question"
        
        self.data_dir = Path(data_dir)
        self.usage_file = self.data_dir / "logs" / "usage.json"
        self.history_file = self.data_dir / "logs" / "history.json"
    
    def load_data(self):
        """加载数据"""
        data = {
            "usage": {},
            "history": [],
            "loaded": False
        }
        
        try:
            if self.usage_file.exists():
                with open(self.usage_file, 'r', encoding='utf-8') as f:
                    data["usage"] = json.load(f)
            
            if self.history_file.exists():
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    data["history"] = json.load(f)
            
            data["loaded"] = True
        except Exception as e:
            print(f"加载数据失败: {e}")
        
        return data
    
    def get_summary(self):
        """获取统计摘要"""
        data = self.load_data()
        if not data["loaded"]:
            return {"error": "无法加载数据"}
        
        usage = data["usage"]
        history = data["history"]
        
        summary = {
            "total_questions": usage.get("total_questions_asked", 0),
            "category_distribution": usage.get("category_distribution", {}),
            "last_asked": usage.get("last_asked"),
            "history_count": len(history)
        }
        
        return summary
    
    def generate_report(self):
        """生成报告"""
        summary = self.get_summary()
        
        if "error" in summary:
            return f"错误: {summary['error']}"
        
        lines = []
        lines.append("=" * 60)
        lines.append("随机提问技能使用报告")
        lines.append("=" * 60)
        lines.append("")
        
        lines.append("📊 基础统计")
        lines.append("-" * 40)
        lines.append(f"总提问次数: {summary['total_questions']}")
        lines.append(f"历史记录数: {summary['history_count']}")
        if summary['last_asked']:
            lines.append(f"最后提问: {summary['last_asked']}")
        lines.append("")
        
        lines.append("🏷️ 类别分布")
        lines.append("-" * 40)
        
        category_names = {
            "A": "内在状态层",
            "B": "身体感知层",
            "C": "思维与创造层",
            "D": "行动与事务层",
            "E": "关系与连接层",
            "F": "环境与情境层",
            "G": "反思与元认知层",
            "H": "未来与导向层"
        }
        
        if summary['category_distribution']:
            for cat, count in sorted(summary['category_distribution'].items()):
                name = category_names.get(cat, cat)
                lines.append(f"{cat} {name}: {count}次")
        
        lines.append("")
        lines.append("=" * 60)
        
        return "\n".join(lines)

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="随机提问技能统计工具")
    parser.add_argument("--report", action="store_true", help="生成完整报告")
    parser.add_argument("--summary", action="store_true", help="显示统计摘要")
    parser.add_argument("--format", choices=["text", "json"], default="text", help="输出格式")
    
    args = parser.parse_args()
    
    if not any([args.report, args.summary]):
        args.report = True
    
    analyzer = QuestionAnalyzer()
    
    if args.summary:
        summary = analyzer.get_summary()
        if args.format == "json":
            print(json.dumps(summary, ensure_ascii=False, indent=2, default=str))
        else:
            print("统计摘要:")
            if "error" in summary:
                print(f"错误: {summary['error']}")
            else:
                print(f"总提问次数: {summary['total_questions']}")
                print(f"历史记录数: {summary['history_count']}")
    
    if args.report:
        report = analyzer.generate_report()
        print(report)

if __name__ == "__main__":
    main()
