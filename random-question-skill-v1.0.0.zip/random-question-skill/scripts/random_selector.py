#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
随机问题选择器
版本: 1.0.0
作者: 咕咕嘎嘎
功能: 从8个维度28个话题中随机选择问题
"""

import random
import json
import os
from datetime import datetime
from pathlib import Path

class RandomQuestionGenerator:
    """随机问题生成器"""
    
    def __init__(self):
        self.questions = self._load_questions()
        
    def _load_questions(self):
        """加载问题库"""
        return {
            "A": {
                "name": "内在状态层",
                "questions": [
                    "此刻主导你情绪的颜色或天气是什么？",
                    "你当下的心理能量是满格、半格还是急需充电？",
                    "今天内心重复播放的'背景音'或一句话是什么？",
                    "如果压力有体积，它现在像一颗豌豆还是一个气球？"
                ]
            },
            "B": {
                "name": "身体感知层",
                "questions": [
                    "身体哪个部位最想引起你的注意？",
                    "试着观察一次呼吸，它是深长还是短促？",
                    "此刻你听到、闻到或感觉到最明显的是什么？",
                    "今天哪一口食物或哪一杯饮品的味道最让你记得？"
                ]
            },
            "C": {
                "name": "思维与创造层",
                "questions": [
                    "当前占据你大脑'前台'的核心念头是什么？",
                    "今天有没有哪怕一瞬的、让你觉得'哎，有点意思'的想法？",
                    "正在处理的事情里，最微妙或最难下决定的一点是什么？",
                    "今天是否有一段忘记时间流逝的沉浸体验？"
                ]
            },
            "D": {
                "name": "行动与事务层",
                "questions": [
                    "今天完成哪件小事后，你在心里给自己点了个赞？",
                    "今天最重要的那根'定海神针'（核心任务）完成得如何？",
                    "今天遇到最有意思或最烦人的'计划外事件'是什么？",
                    "今天有什么工具、方法或一句话显著提升了你的效率？"
                ]
            },
            "E": {
                "name": "关系与连接层",
                "questions": [
                    "今天来自他人最让你感到温暖的一个举动或一句话是？",
                    "今天是否有一刻希望被理解或陪伴？那是什么情境？",
                    "今天你为他人提供的、让自己也感到开心的一次小帮助是什么？"
                ]
            },
            "F": {
                "name": "环境与情境层",
                "questions": [
                    "今天不同场所给你的感受有何不同？",
                    "手机/电脑里哪个App或文件今天最常被你打开？"
                ]
            },
            "G": {
                "name": "反思与元认知层",
                "questions": [
                    "如果回顾最近三天，你发现自己一个无意识的重复行为是什么？",
                    "今天你对自己说得最多的一句鼓励或批评的话是什么？",
                    "如果五年后的你穿越回来，会对此刻的你说哪句话？",
                    "用一个比喻来定义今天，它像一本什么书或哪种天气？"
                ]
            },
            "H": {
                "name": "未来与导向层",
                "questions": [
                    "明天早晨醒来，你第一件想做的事是什么？",
                    "未来一周，你最期待的一个非任务型事件是什么？",
                    "如果现在可以放下对一件事情的担忧，你希望是哪件？"
                ]
            }
        }
    
    def get_random_question(self):
        """获取随机问题"""
        categories = list(self.questions.keys())
        category = random.choice(categories)
        category_data = self.questions[category]
        question = random.choice(category_data["questions"])
        
        return {
            "question": question,
            "category": category,
            "category_name": category_data["name"],
            "timestamp": datetime.now().isoformat()
        }
    
    def get_all_questions(self):
        """获取所有问题"""
        all_questions = []
        for category, data in self.questions.items():
            for question in data["questions"]:
                all_questions.append({
                    "question": question,
                    "category": category,
                    "category_name": data["name"]
                })
        return all_questions

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="随机问题生成器")
    parser.add_argument("--force", "-f", action="store_true", help="强制获取问题")
    parser.add_argument("--list", "-l", action="store_true", help="列出所有问题")
    parser.add_argument("--format", choices=["json", "text"], default="text", help="输出格式")
    
    args = parser.parse_args()
    
    generator = RandomQuestionGenerator()
    
    if args.list:
        questions = generator.get_all_questions()
        if args.format == "json":
            print(json.dumps(questions, ensure_ascii=False, indent=2))
        else:
            for q in questions:
                print(f"[{q['category']}] {q['category_name']}: {q['question']}")
    else:
        result = generator.get_random_question()
        if args.format == "json":
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"类别: {result['category_name']} ({result['category']})")
            print(f"问题: {result['question']}")

if __name__ == "__main__":
    main()
