#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""验证脚本"""

import sys
import os

# 设置编码
os.environ['PYTHONIOENCODING'] = 'utf-8'
sys.stdout.reconfigure(encoding='utf-8')

sys.path.insert(0, r'C:\Users\17985\Desktop\新建文件夹')

try:
    from scripts.random_selector import RandomQuestionGenerator
    print("[OK] Import successful")
    
    g = RandomQuestionGenerator()
    print("[OK] Generator initialized")
    
    q = g.get_random_question()
    print("[OK] Random question obtained")
    print(f"Question: {q['question']}")
    print(f"Category: {q['category_name']}")
    
    all_q = g.get_all_questions()
    print(f"[OK] Total questions: {len(all_q)}")
    
    print("\n[SUCCESS] All tests passed!")
    
except Exception as e:
    print(f"[ERROR] {e}")
    import traceback
    traceback.print_exc()
