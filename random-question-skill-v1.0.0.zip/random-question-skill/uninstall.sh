#!/bin/bash
# Random Question Skill 卸载脚本
# 版本: 1.0.0
# 作者: 咕咕嘎嘎

set -e

echo "🗑️  开始卸载 Random Question Skill"
echo "=================================="

# 获取安装目录
OPENCLAW_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
WORKSPACE_DIR="$OPENCLAW_HOME/workspace"
SKILLS_DIR="$WORKSPACE_DIR/skills"
RANDOM_QUESTION_DIR="$SKILLS_DIR/random-question"

echo "📁 安装目录: $OPENCLAW_HOME"

# 确认卸载
read -p "确定要卸载 Random Question Skill 吗？(y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ 卸载已取消"
    exit 0
fi

# 备份配置文件
echo "💾 备份配置文件..."
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/tmp/openclaw-backup-$TIMESTAMP"
mkdir -p "$BACKUP_DIR"

if [ -d "$RANDOM_QUESTION_DIR/config" ]; then
    cp -r "$RANDOM_QUESTION_DIR/config" "$BACKUP_DIR/"
    echo "✅ 备份配置文件"
fi

if [ -d "$RANDOM_QUESTION_DIR/logs" ]; then
    cp -r "$RANDOM_QUESTION_DIR/logs" "$BACKUP_DIR/"
    echo "✅ 备份日志文件"
fi

# 删除技能目录
echo "🗑️  删除技能文件..."
if [ -d "$RANDOM_QUESTION_DIR" ]; then
    rm -rf "$RANDOM_QUESTION_DIR"
    echo "✅ 删除技能目录"
fi

echo ""
echo "✅ 卸载完成！"
echo "📁 备份文件保存在: $BACKUP_DIR"
echo ""
echo "👋 感谢使用 Random Question Skill！"
