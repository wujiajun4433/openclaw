#!/bin/bash
# Random Question Skill 安装脚本
# 版本: 1.0.0
# 作者: 咕咕嘎嘎
# 日期: 2026-03-25

set -e

echo "🔧 开始安装 Random Question Skill v1.0.0"
echo "========================================"

# 检查 OpenClaw 安装
if ! command -v openclaw &> /dev/null; then
    echo "❌ 错误: OpenClaw 未安装或不在 PATH 中"
    exit 1
fi

echo "✅ 检测到 OpenClaw"

# 获取安装目录
OPENCLAW_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
WORKSPACE_DIR="$OPENCLAW_HOME/workspace"
SKILLS_DIR="$WORKSPACE_DIR/skills"
RANDOM_QUESTION_DIR="$SKILLS_DIR/random-question"

echo "📁 安装目录: $OPENCLAW_HOME"
echo ""
echo "📦 正在安装技能文件..."

# 创建目录结构
mkdir -p "$RANDOM_QUESTION_DIR"
mkdir -p "$RANDOM_QUESTION_DIR/scripts"
mkdir -p "$RANDOM_QUESTION_DIR/config"
mkdir -p "$RANDOM_QUESTION_DIR/logs"
mkdir -p "$RANDOM_QUESTION_DIR/docs"

# 复制文件
echo "📄 复制文件..."
cp -r . "$RANDOM_QUESTION_DIR/" 2>/dev/null || true

# 设置执行权限
chmod +x "$RANDOM_QUESTION_DIR/scripts/random_selector.py"
chmod +x "$RANDOM_QUESTION_DIR/scripts/question_stats.py"

echo ""
echo "✅ 安装完成！"
echo ""
echo "📋 后续步骤："
echo "1. 查看技能详情: openclaw skill info random-question"
echo "2. 测试技能: openclaw run '随机问我一个问题'"
echo "3. 配置 Heartbeat: 编辑 $WORKSPACE_DIR/HEARTBEAT.md"
echo ""
echo "🚀 开始使用吧！"
