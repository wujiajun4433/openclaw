# 常见问题 (FAQ)

## 安装相关

### Q: 如何安装这个技能？
A: 有两种方式：

**方式1: 使用安装脚本**
```bash
chmod +x install.sh
./install.sh
```

**方式2: 手动安装**
```bash
mkdir -p ~/.openclaw/workspace/skills/random-question
cp -r scripts/ ~/.openclaw/workspace/skills/random-question/
cp SKILL.md ~/.openclaw/workspace/skills/random-question/
```

### Q: 安装失败怎么办？
A: 检查以下几点：
1. OpenClaw 是否已安装：`openclaw --version`
2. 权限是否正确：`ls -la ~/.openclaw/`
3. 查看日志：`tail -f ~/.openclaw/logs/openclaw.log`

### Q: 可以卸载吗？
A: 可以，运行卸载脚本：
```bash
chmod +x uninstall.sh
./uninstall.sh
```

---

## 使用相关

### Q: 如何手动触发提问？
A: 有多种方式：
```
说: "随机问我一个问题"
说: "!ask-random"
说: "来个随机问题"
说: "我想被提问一下"
```

### Q: 如何修改提问频率？
A: 编辑配置文件：
```bash
vim ~/.openclaw/workspace/skills/random-question/config/default.yaml
```

修改这些参数：
```yaml
settings:
  trigger_probability: 30      # 触发概率 (0-100)
  min_interval_minutes: 30     # 最小间隔
  active_hours:
    start: "08:00"             # 开始时间
    end: "23:00"               # 结束时间
```

### Q: 如何排除某些问题？
A: 在配置文件中添加：
```yaml
personalization:
  excluded_questions:
    - "B1"  # 身体信号
    - "G4"  # 定义今天
```

### Q: 如何设置偏好的问题类别？
A: 在配置文件中添加：
```yaml
personalization:
  favorite_categories:
    - "A"  # 内在状态层
    - "G"  # 反思与元认知层
```

---

## 数据相关

### Q: 数据存储在哪里？
A: 所有数据存储在本地：
```
~/.openclaw/workspace/skills/random-question/logs/
├── usage.json      # 使用统计
├── history.json    # 历史记录
└── *.log          # 日志文件
```

### Q: 如何导出数据？
A: 使用统计脚本导出：
```bash
# JSON 格式
python3 scripts/question_stats.py --report --format json > report.json

# CSV 格式
python3 scripts/question_stats.py --trends --format csv > trends.csv

# 生成图表
python3 scripts/question_stats.py --plot usage_trend.png
```

### Q: 如何清除历史记录？
A: 删除日志文件：
```bash
rm ~/.openclaw/workspace/skills/random-question/logs/history.json
```

### Q: 数据会被上传到云端吗？
A: 不会。所有数据完全本地存储，不会上传任何地方。

---

## 功能相关

### Q: 支持多少个问题？
A: 目前有 28 个核心问题，分为 8 个维度：
- A: 内在状态层 (4个)
- B: 身体感知层 (4个)
- C: 思维与创造层 (4个)
- D: 行动与事务层 (4个)
- E: 关系与连接层 (3个)
- F: 环境与情境层 (2个)
- G: 反思与元认知层 (4个)
- H: 未来与导向层 (3个)

### Q: 可以添加自定义问题吗？
A: 可以。编辑 SKILL.md 文件，在相应类别下添加新问题。

### Q: 支持多语言吗？
A: 目前只支持中文。未来版本会支持英文和其他语言。

### Q: 可以与其他技能集成吗？
A: 可以。查看 docs/examples.md 了解集成方式。

---

## 故障排除

### Q: 没有收到提问
A: 检查以下几点：
1. Heartbeat 服务是否运行：`openclaw heartbeat status`
2. 是否在活跃时间段内
3. 触发概率是否设置过低
4. 查看日志：`tail -f ~/.openclaw/logs/heartbeat.log`

### Q: 提问太频繁
A: 调整配置：
```yaml
settings:
  trigger_probability: 10      # 降低概率
  min_interval_minutes: 60     # 增加间隔
```

### Q: 问题重复
A: 这是正常的。如果想减少重复：
```yaml
settings:
  question_weights:
    category_distribution: "recent"  # 优先选择最近少问的
```

### Q: 脚本运行出错
A: 检查 Python 版本和依赖：
```bash
python3 --version  # 需要 3.6+
pip3 install pyyaml pandas matplotlib  # 安装依赖
```

---

## 高级功能

### Q: 如何通过 API 调用？
A: 使用 Python API：
```python
from scripts.random_selector import RandomQuestionGenerator

generator = RandomQuestionGenerator()
question = generator.get_random_question(force=True)
print(question['question'])
```

### Q: 如何生成统计报告？
A: 使用统计脚本：
```bash
python3 scripts/question_stats.py --report
python3 scripts/question_stats.py --summary
python3 scripts/question_stats.py --trends
```

### Q: 如何自定义触发条件？
A: 编辑 HEARTBEAT.md 文件，自定义触发逻辑。

### Q: 支持 Webhook 吗？
A: 目前不支持，但可以通过自定义脚本实现。

---

## 贡献与反馈

### Q: 如何报告 Bug？
A: 提交 GitHub Issue，包含：
1. 问题描述
2. 复现步骤
3. 日志文件
4. 系统信息

### Q: 如何提交功能建议？
A: 提交 GitHub Discussion 或 Issue。

### Q: 可以贡献代码吗？
A: 欢迎！请 Fork 项目并提交 Pull Request。

---

## 许可证与使用

### Q: 这个项目是开源的吗？
A: 是的，采用 MIT License。

### Q: 可以商业使用吗？
A: 可以，MIT License 允许商业使用。

### Q: 需要署名吗？
A: 不需要，但欢迎署名。

---

## 更多帮助

- 📖 查看完整文档：README.md
- 💻 查看代码示例：docs/examples.md
- 🔧 查看 API 文档：docs/API.md
- 📝 查看版本日志：docs/CHANGELOG.md

**还有其他问题？提交 Issue 或联系我们！**
