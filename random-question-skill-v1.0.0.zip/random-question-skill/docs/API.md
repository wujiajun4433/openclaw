# API 文档

## Python API

### RandomQuestionGenerator 类

#### 初始化

```python
from scripts.random_selector import RandomQuestionGenerator

# 使用默认配置
generator = RandomQuestionGenerator()

# 使用自定义配置
generator = RandomQuestionGenerator(config_path="/path/to/config.yaml")
```

#### 获取随机问题

```python
# 获取随机问题（遵守触发条件）
question = generator.get_random_question()

# 强制获取问题（忽略触发条件）
question = generator.get_random_question(force=True)

# 返回值示例
{
    "question": "此刻主导你情绪的颜色或天气是什么？",
    "category": "A",
    "category_name": "内在状态层",
    "timestamp": "2026-03-25T14:56:00",
    "should_ask": True
}
```

#### 获取指定类别问题

```python
# 获取 A 类别的随机问题
question = generator.get_question_by_category("A")

# 返回值示例
"此刻主导你情绪的颜色或天气是什么？"
```

#### 获取所有问题

```python
# 获取所有问题列表
all_questions = generator.get_all_questions()

# 返回值示例
[
    {
        "question": "此刻主导你情绪的颜色或天气是什么？",
        "category": "A",
        "category_name": "内在状态层"
    },
    ...
]
```

#### 获取统计信息

```python
# 获取统计信息
stats = generator.get_stats()

# 返回值示例
{
    "total_questions": 42,
    "category_distribution": {
        "A": 5,
        "B": 6,
        "C": 7,
        ...
    },
    "last_asked": "2026-03-25T14:56:00",
    "history_count": 42
}
```

---

### QuestionAnalyzer 类

#### 初始化

```python
from scripts.question_stats import QuestionAnalyzer

# 使用默认数据目录
analyzer = QuestionAnalyzer()

# 使用自定义数据目录
analyzer = QuestionAnalyzer(data_dir="/path/to/data")
```

#### 获取统计摘要

```python
# 获取统计摘要
summary = analyzer.get_summary()

# 返回值示例
{
    "total_questions": 42,
    "category_distribution": {...},
    "last_asked": "2026-03-25T14:56:00",
    "hours_since_last": 2.5,
    "date_range": {
        "start": "2026-03-01",
        "end": "2026-03-25",
        "days": 25
    },
    "avg_questions_per_day": 1.68,
    ...
}
```

#### 获取趋势数据

```python
# 获取最近 30 天的趋势
trends = analyzer.get_trends(days=30)

# 返回值示例
{
    "dates": ["03-01", "03-02", ...],
    "question_counts": [2, 1, 3, ...],
    "moving_average": [None, None, 2.0, ...],
    "category_trends": {
        "A": [1, 0, 1, ...],
        "B": [1, 1, 2, ...],
        ...
    },
    "total_last_30_days": 50,
    "avg_per_day_last_30": 1.67,
    ...
}
```

#### 生成报告

```python
# 生成文本格式报告
report = analyzer.generate_report(format="text")
print(report)

# 生成 JSON 格式报告
report = analyzer.generate_report(format="json")
import json
print(json.dumps(json.loads(report), indent=2))
```

#### 绘制图表

```python
# 生成图表并保存
analyzer.plot_usage_trend(output_file="usage_trend.png")

# 显示图表（需要 GUI）
analyzer.plot_usage_trend()
```

---

## 命令行 API

### random_selector.py

#### 获取随机问题

```bash
# 基本用法
python3 scripts/random_selector.py

# 强制获取
python3 scripts/random_selector.py --force

# 指定类别
python3 scripts/random_selector.py --category A

# JSON 格式输出
python3 scripts/random_selector.py --format json

# Announce 格式（用于 OpenClaw）
python3 scripts/random_selector.py --format announce
```

#### 显示统计信息

```bash
# 显示统计摘要
python3 scripts/random_selector.py --stats

# JSON 格式
python3 scripts/random_selector.py --stats --format json
```

#### 列出所有问题

```bash
# 列出所有问题
python3 scripts/random_selector.py --list

# JSON 格式
python3 scripts/random_selector.py --list --format json
```

#### 自定义配置

```bash
# 使用自定义配置文件
python3 scripts/random_selector.py --config /path/to/config.yaml
```

---

### question_stats.py

#### 生成报告

```bash
# 生成完整报告
python3 scripts/question_stats.py --report

# JSON 格式
python3 scripts/question_stats.py --report --format json
```

#### 显示摘要

```bash
# 显示统计摘要
python3 scripts/question_stats.py --summary

# JSON 格式
python3 scripts/question_stats.py --summary --format json
```

#### 显示趋势

```bash
# 显示趋势数据
python3 scripts/question_stats.py --trends

# CSV 格式
python3 scripts/question_stats.py --trends --format csv
```

#### 生成图表

```bash
# 生成图表
python3 scripts/question_stats.py --plot usage_trend.png

# 自定义数据目录
python3 scripts/question_stats.py --plot usage_trend.png --data-dir /path/to/data
```

---

## REST API (计划中)

### 端点

#### GET /api/random-question

获取随机问题

**请求:**
```bash
curl http://localhost:3000/api/random-question
```

**响应:**
```json
{
    "question": "此刻主导你情绪的颜色或天气是什么？",
    "category": "A",
    "category_name": "内在状态层",
    "timestamp": "2026-03-25T14:56:00"
}
```

#### GET /api/stats

获取统计信息

**请求:**
```bash
curl http://localhost:3000/api/stats
```

**响应:**
```json
{
    "total_questions": 42,
    "category_distribution": {...},
    "last_asked": "2026-03-25T14:56:00"
}
```

#### GET /api/questions

获取所有问题

**请求:**
```bash
curl http://localhost:3000/api/questions
```

**响应:**
```json
[
    {
        "question": "此刻主导你情绪的颜色或天气是什么？",
        "category": "A",
        "category_name": "内在状态层"
    },
    ...
]
```

#### GET /api/trends

获取趋势数据

**请求:**
```bash
curl http://localhost:3000/api/trends?days=30
```

**响应:**
```json
{
    "dates": ["03-01", "03-02", ...],
    "question_counts": [2, 1, 3, ...],
    "total_last_30_days": 50,
    "avg_per_day_last_30": 1.67
}
```

---

## 集成示例

### 与 OpenClaw 集成

```python
# 在 OpenClaw 技能中使用
from scripts.random_selector import RandomQuestionGenerator

def handle_random_question_request():
    generator = RandomQuestionGenerator()
    question = generator.get_random_question(force=True)
    
    if question:
        return f"!announce {question['question']}"
    else:
        return "现在不是提问的合适时机"
```

### 与日记技能集成

```python
# 在日记技能中调用
from scripts.random_selector import RandomQuestionGenerator

def start_daily_journal():
    generator = RandomQuestionGenerator()
    question = generator.get_random_question(force=True)
    
    if question:
        return {
            "prompt": f"请回答这个问题：{question['question']}",
            "category": question['category']
        }
```

### 自定义工作流

```python
# 创建自定义工作流
from scripts.random_selector import RandomQuestionGenerator
from scripts.question_stats import QuestionAnalyzer

def morning_reflection():
    # 获取随机问题
    generator = RandomQuestionGenerator()
    question = generator.get_random_question(force=True)
    
    # 获取统计信息
    analyzer = QuestionAnalyzer()
    stats = analyzer.get_summary()
    
    return {
        "question": question['question'],
        "stats": stats,
        "timestamp": datetime.now().isoformat()
    }
```

---

## 错误处理

### 常见错误

```python
# 配置文件不存在
try:
    generator = RandomQuestionGenerator(config_path="/invalid/path")
except FileNotFoundError:
    print("配置文件不存在")

# 无效的类别
question = generator.get_question_by_category("Z")
if question is None:
    print("类别不存在")

# 数据加载失败
analyzer = QuestionAnalyzer()
data = analyzer.load_data()
if not data["loaded"]:
    print("无法加载数据")
```

---

## 性能优化

### 缓存

```python
# 缓存生成器实例
_generator = None

def get_generator():
    global _generator
    if _generator is None:
        _generator = RandomQuestionGenerator()
    return _generator

# 使用缓存
question = get_generator().get_random_question()
```

### 批量操作

```python
# 批量获取问题
questions = []
for i in range(10):
    q = generator.get_random_question(force=True)
    if q:
        questions.append(q)
```

---

## 版本信息

- **当前版本:** 1.0.0
- **Python 版本:** 3.6+
- **依赖:** pyyaml, pandas, matplotlib
- **最后更新:** 2026-03-25

---

## 更多帮助

- 📖 查看完整文档：README.md
- ❓ 查看常见问题：docs/FAQ.md
- 💻 查看代码示例：docs/examples.md
- 📝 查看版本日志：docs/CHANGELOG.md
