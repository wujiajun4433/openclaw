#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""完整验证脚本"""

import sys
import os
import json
from pathlib import Path

os.environ['PYTHONIOENCODING'] = 'utf-8'
sys.stdout.reconfigure(encoding='utf-8')

base_dir = Path(r'C:\Users\17985\Desktop\新建文件夹')
sys.path.insert(0, str(base_dir))

print("=" * 60)
print("PROJECT VERIFICATION REPORT")
print("=" * 60)
print()

# 1. 检查文件结构
print("[1] Checking file structure...")
required_files = [
    'SKILL.md',
    'README.md',
    'HEARTBEAT.md',
    'example-openclaw.json',
    'install.sh',
    'uninstall.sh',
    'scripts/random_selector.py',
    'scripts/question_stats.py',
    'config/default.yaml',
    'logs/usage.json',
    'logs/history.json',
    'docs/FAQ.md',
    'docs/API.md',
    'docs/CHANGELOG.md',
]

missing_files = []
for file in required_files:
    file_path = base_dir / file
    if file_path.exists():
        print(f"  [OK] {file}")
    else:
        print(f"  [MISSING] {file}")
        missing_files.append(file)

print()

# 2. 测试Python脚本
print("[2] Testing Python scripts...")
try:
    from scripts.random_selector import RandomQuestionGenerator
    g = RandomQuestionGenerator()
    q = g.get_random_question()
    all_q = g.get_all_questions()
    print(f"  [OK] random_selector.py works")
    print(f"      - Random question: {q['question'][:30]}...")
    print(f"      - Total questions: {len(all_q)}")
except Exception as e:
    print(f"  [ERROR] random_selector.py: {e}")

try:
    from scripts.question_stats import QuestionAnalyzer
    analyzer = QuestionAnalyzer()
    summary = analyzer.get_summary()
    print(f"  [OK] question_stats.py works")
    print(f"      - Summary: {summary}")
except Exception as e:
    print(f"  [ERROR] question_stats.py: {e}")

print()

# 3. 检查配置文件
print("[3] Checking configuration files...")
try:
    with open(base_dir / 'config/default.yaml', 'r', encoding='utf-8') as f:
        content = f.read()
        if 'trigger_probability' in content:
            print(f"  [OK] config/default.yaml is valid")
        else:
            print(f"  [WARNING] config/default.yaml may be incomplete")
except Exception as e:
    print(f"  [ERROR] config/default.yaml: {e}")

try:
    with open(base_dir / 'logs/usage.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
        print(f"  [OK] logs/usage.json is valid JSON")
except Exception as e:
    print(f"  [ERROR] logs/usage.json: {e}")

try:
    with open(base_dir / 'logs/history.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
        print(f"  [OK] logs/history.json is valid JSON")
except Exception as e:
    print(f"  [ERROR] logs/history.json: {e}")

print()

# 4. 检查文档
print("[4] Checking documentation...")
doc_files = ['docs/FAQ.md', 'docs/API.md', 'docs/CHANGELOG.md', 'README.md', 'SKILL.md']
for doc in doc_files:
    doc_path = base_dir / doc
    if doc_path.exists():
        size = doc_path.stat().st_size
        print(f"  [OK] {doc} ({size} bytes)")
    else:
        print(f"  [MISSING] {doc}")

print()

# 5. 总结
print("[5] Summary")
print("-" * 60)
total_files = len(list(base_dir.rglob('*')))
total_dirs = len(list(base_dir.rglob('*'))) - len(list(base_dir.rglob('*.*')))

print(f"Total files: {len(list(base_dir.rglob('*.*')))}")
print(f"Total directories: {total_dirs}")
print(f"Missing files: {len(missing_files)}")

if missing_files:
    print(f"\nMissing files:")
    for f in missing_files:
        print(f"  - {f}")
else:
    print("\n[SUCCESS] All files present!")

print()
print("=" * 60)
print("VERIFICATION COMPLETE")
print("=" * 60)
